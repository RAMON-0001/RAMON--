<?php
include(__DIR__ . "/../php/info.php");
